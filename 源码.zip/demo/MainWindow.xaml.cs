﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using demo.PacketUtils;

namespace demo
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public byte[] packet;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string aib2 = authinfo.Text;
            string _data = data.Text;

            if (aib2 == null || data == null)
            {
                packetSize.Text = "请检查是否输入了内容！";
                e.Handled = true;
                return;
            }

            PacketHelper ph = new PacketHelper(0x11,
                aib2,
                Encoding.ASCII.GetBytes(Convert.ToBase64String(Encoding.UTF8.GetBytes(_data)))
                );

            packet = ph.CreatePacket();

            packetSize.Text = "生成的包：\n"+GetBytesString(packet,0,packet.Length,"")+"\n"+"包大小："+packet.Length;

            e.Handled = true;
            return;
        }

        private static string GetBytesString(byte[] bytes, int index, int count, string sep)
        {
            return new string(bytes.Skip(index).Take(count - 1).Select(b => b.ToString("X2") + sep).SelectMany(i => i.ToCharArray()).Concat(bytes.Skip(index + count - 1).Take(1).SelectMany(b => b.ToString("X2").ToCharArray())).ToArray());
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (packet == null)
            {
                info.Text = "还未生成过数据包";
                e.Handled = true;
                return;
            }
            PacketStruct ps = PacketHelper.ParsePacket(packet);
            string aib2 = Encoding.UTF8.GetString(Convert.FromBase64String(Encoding.ASCII.GetString(ps.aib2)));
            string data = Encoding.UTF8.GetString(Convert.FromBase64String(Encoding.ASCII.GetString(ps.data)));
            info.Text = "aib2块信息：\n" + aib2 + "\n" + "data块信息：\n" + data;
            e.Handled = true;
            return;
        }
    }
}
