﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace demo.PacketUtils
{
    public class PacketHelper
    {
        private static readonly byte[] MAGIC_NUMBER = { 0xA9, 0xB7, 0x7C, 0x9D };
        private PacketStruct ps = new PacketStruct();
        private Random rd = new Random();
        public PacketHelper(byte aib1_Info,string aib2_Info, byte[] data)
        {
            this.ps.randomStartPos = BitConverter.GetBytes(rd.Next(0, 7))[0];
            this.ps.aib1 = aib1_Info;
            this.ps.aib2 = Encoding.ASCII.GetBytes(Convert.ToBase64String(Encoding.UTF8.GetBytes(aib2_Info)));
            this.ps.aib2Length = this.ps.aib2.Length;
            this.ps.aib3 = new byte[8];
            Buffer.BlockCopy(MD5.Create().ComputeHash(this.ps.aib2), this.ps.randomStartPos, this.ps.aib3, 0, 8);

            this.ps.data = data;
            this.ps.dataLength = data.Length;

            this.ps.dataHash = new byte[8];
            Buffer.BlockCopy(MD5.Create().ComputeHash(data), this.ps.randomStartPos, this.ps.dataHash, 0, 8);
        }
        public byte[] CreatePacket()
        {
            int packetLength = 13 + 1 + this.ps.aib2Length + 8 + this.ps.dataLength + 8;

            byte[] packet = new byte[packetLength];
            int pos = 0;

            //魔数
            MAGIC_NUMBER.CopyTo(packet, pos);
            pos += 4;
            //aib2l
            BitConverter.GetBytes(this.ps.aib2Length)
                .Reverse().ToArray()
                .CopyTo(packet, pos);
            pos += 4;
            //stp
            new byte[] { (byte)this.ps.randomStartPos }.CopyTo(packet, pos);
            pos += 1;
            //dtl
            BitConverter.GetBytes(this.ps.dataLength)
                .Reverse().ToArray()
                .CopyTo(packet, pos);
            pos += 4;
            //aib1
            new byte[] { this.ps.aib1 }.CopyTo(packet, pos);
            pos += 1;
            //aib2
            this.ps.aib2.CopyTo(packet, pos);
            pos += this.ps.aib2Length;
            //aib3
            this.ps.aib3.CopyTo(packet, pos);
            pos += 8;
            //data
            this.ps.data.CopyTo(packet, pos);
            pos += this.ps.dataLength;
            //dataHash
            this.ps.dataHash.CopyTo(packet, pos);

            return packet;
        }
        public static PacketStruct ParsePacket(byte[] packet)
        {
            //初步检查
            if (packet.Length <= 16)
            {
                return null;
            }

            PacketStruct p = new PacketStruct();

            MemoryStream buffer = new MemoryStream(packet);

            //声明字段
            byte[] MagicNumber;
            int aib2Length;
            int randomStartPos;
            int dataLength;

            byte aib1;
            byte[] aib2;
            byte[] aib3;

            byte[] data;
            byte[] dataHash;

            //读取
            try
            {
                MagicNumber = new byte[4];
                buffer.Read(MagicNumber, 0, MagicNumber.Length);

                byte[] temp0 = new byte[4];
                buffer.Read(temp0, 0, 4);
                aib2Length = BitConverter.ToInt32(temp0.Reverse().ToArray(), 0);

                randomStartPos = buffer.ReadByte();

                byte[] temp1 = new byte[4];
                buffer.Read(temp1, 0, 4);
                dataLength = BitConverter.ToInt32(temp1.Reverse().ToArray(), 0);

                aib1 = (byte)buffer.ReadByte();

                aib2 = new byte[aib2Length];
                buffer.Read(aib2, 0, aib2Length);

                aib3 = new byte[8];
                buffer.Read(aib3, 0, 8);

                data = new byte[dataLength];
                buffer.Read(data, 0, dataLength);

                dataHash = new byte[8];
                buffer.Read(dataHash, 0, 8);
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                return null;
            }

            //检查 此处忽略
            //TODO: 检查部分的代码

            //生成返回的结构
            p.MagicNumber = MagicNumber;
            p.aib2Length = aib2Length;
            p.randomStartPos = randomStartPos;
            p.dataLength = dataLength;

            p.aib1 = aib1;
            p.aib2 = aib2;
            p.aib3 = aib3;

            p.data = data;
            p.dataHash = dataHash;

            return p;
        }
    }
}