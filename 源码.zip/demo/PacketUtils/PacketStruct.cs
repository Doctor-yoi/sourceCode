﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.PacketUtils
{
    public class PacketStruct
    {
        public byte[] MagicNumber = { 0xA9, 0xB7, 0x7C, 0x9D };
        public int aib2Length { get; set; }
        public int randomStartPos { get; set; }
        public int dataLength { get; set; }

        public byte aib1 { get; set; }
        public byte[] aib2 { get; set; }
        public byte[] aib3 { get; set; }

        public byte[] data { get; set; }
        public byte[] dataHash { get; set; }

        public PacketStruct()
        {

        }
    }
}
